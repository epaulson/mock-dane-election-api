while true; do
   TIMESTAMP=$(date +%s)
   curl https://api.countyofdane.com/api/v1/elections/list >electionlist.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/election/130/ >election.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/races/130/ >races.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/electionresults/130/ >electionresults.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/lastpublished/130/ >lastpublished.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/precinctresults/130/0004/ >statesenate_p.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/precinctresults/130/0005/ >dpi_p.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/precinctresults/130/0018/ >cb12_p.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/electionresults/130/0004/ >statesenate.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/electionresults/130/0005/ >dpi.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/electionresults/130/0018/ >cb12.$TIMESTAMP
   sleep 180 
done
