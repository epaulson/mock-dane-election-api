while true; do
   TIMESTAMP=$(date +%s)
   curl https://api.countyofdane.com/api/v1/elections/precinctresults/127/0020/ >dpi.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/precinctresults/127/0022/ >cb12.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/electionresults/127/ >electionresults.$TIMESTAMP
   curl https://api.countyofdane.com/api/v1/elections/lastpublished/127/ >lastpublished.$TIMESTAMP
   sleep 120 
done
